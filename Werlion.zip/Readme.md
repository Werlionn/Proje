# Hack-Tools
Termux için gerekli 21 araç
<br><b>Kurulum</b><br>
1=) pkg install git -y<br>
2=) git clone https://github.com/yamanefkar/Hack-Tools<br>
3=) cd Hack-Tools<br>
4=) bash start.sh
